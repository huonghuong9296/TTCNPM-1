<?php
/**
 * Created by PhpStorm.
 * User: khang ho
 * Date: 3/30/2019
 * Time: 1:50 PM
 */
session_start();
if(!session_is_registered(myusername)){
    header("location:main_login.php");
}
?>
<html>
<body>
Đăng nhập thành công !
</body>
</html>
