<?php
/**
 * Created by PhpStorm.
 * User: khang ho
 * Date: 3/30/2019
 * Time: 1:51 PM
 */
session_start();
session_destroy();
